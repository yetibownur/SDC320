using System.ComponentModel.DataAnnotations;

namespace McBrideGymGains.Models
{
    public class Achievement
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public bool IsUnlocked { get; set; }

        public Achievement(string title)
        {
            Title = title;
            IsUnlocked = false;
        }
    }
}
