using Microsoft.EntityFrameworkCore;
using McBrideGymGains.Models;

namespace McBrideGymGains.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Achievement> Achievements { get; set; }
        public DbSet<ExerciseData> Exercises { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=McBrideGymGains.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Achievement>().HasData(
                new Achievement("First Workout!") { Id = 1, IsUnlocked = false },
                new Achievement("Lifted 1000kg Total!") { Id = 2, IsUnlocked = false },
                new Achievement("10 Workouts Completed!") { Id = 3, IsUnlocked = false }
            );
        }
    }
}
