using System.ComponentModel.DataAnnotations;

namespace McBrideGymGains.Models
{
    public class ExerciseData
    {
        [Key]
        public int Id { get; set; }
        public string ExerciseName { get; set; } = string.Empty;
        public string MuscleGroup { get; set; } = string.Empty;
        public int Sets { get; set; }
        public int Reps { get; set; }
        public int Weight { get; set; }

        public int CalculateTotalWeight => Sets * Reps * Weight;

        public override string ToString()
        {
            return $"{ExerciseName} ({MuscleGroup}) - {Sets} sets x {Reps} reps @ {Weight}kg";
        }
    }
}
