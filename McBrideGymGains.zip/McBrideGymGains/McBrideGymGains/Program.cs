﻿using System;
using McBrideGymGains.Data;

namespace McBrideGymGains
{
    class Program
    {
        static void Main(string[] args)
        {
            using var dbContext = new AppDbContext();
            Console.WriteLine("Database initialized successfully!");
        }
    }
}
